import React from 'react'

function Error() {
  return (
    <div style={{margin:"50%"}}><h1>Error</h1></div>
  )
}

export default Error